package com.mindtree.employee.service;

import java.util.List;

import com.mindtree.employee.entity.Employee;
import com.mindtree.employee.exception.EmployeeDashboardAppException;

public interface EmployeeService {

	String addEmployee(Employee employee) throws EmployeeDashboardAppException;

	Employee fetchEmployeeById(int id) throws EmployeeDashboardAppException;

	List<Employee> getEmployees() throws EmployeeDashboardAppException;

	String deleteEmployee(int id) throws EmployeeDashboardAppException;

	Object updateEmpl(Employee employee);

}
