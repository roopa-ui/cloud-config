package com.mindtree.employee.service.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.employee.dao.EmployeeDao;
import com.mindtree.employee.entity.Employee;
import com.mindtree.employee.exception.EmployeeDashboardAppException;
import com.mindtree.employee.exception.EmployeeNotFoundException;
import com.mindtree.employee.exception.InputMisMatchException;
import com.mindtree.employee.exception.NameFormatException;
import com.mindtree.employee.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeDao employeeDao;
	
	private static final String name_exp = "^[a-zA-Z\\s]+$";

	@Override
	public String addEmployee(Employee employee) throws EmployeeDashboardAppException {
		if(employee.getSalary() < 1) {
			throw new InputMisMatchException("Salary Cannot be negative ");
		}
		if(!(employee.getDeptName().matches(name_exp) || employee.getEmployeeName().matches(name_exp)))
		{
			throw new NameFormatException("Employee Name or Deparart Name Should contain only String....!");
		}
		Employee employeeAdded = employeeDao.addEmployee(employee);
		return "Employee Added Successfully WITH Employee ID - "+employeeAdded.getEmployeeId();	
	}

	@Override
	public Employee fetchEmployeeById(int id) throws EmployeeDashboardAppException {
		if(id<1) {
			throw new InputMisMatchException("Employee ID Should not be negative value..!");
		}
		Optional<Employee> employeeFetched =  employeeDao.fetchEmployeeById(id);
		if(!employeeFetched.isPresent()) {
			throw new EmployeeNotFoundException("Employee by ID - "+id +" does not exists...!");
		}
		return employeeFetched.get();
	}

	@Override
	public List<Employee> getEmployees() throws EmployeeDashboardAppException {
		List<Employee> employees;
		employees = employeeDao.getEmployees();
		if(employees.isEmpty()) {
			throw new EmployeeNotFoundException("Employees Not Found in DB..!");
		}
		return employees;
	}

	@Override
	public String deleteEmployee(int id) throws EmployeeDashboardAppException {
		if(id<1) {
			throw new InputMisMatchException("Employee ID  Should not be negative");
		}
		employeeDao.deleteEmployee(id);
		return "Employee with ID -"+id +" Has been deleted SuccessFully..!";
	}

	@Override
	public Object updateEmpl(Employee employee) {
		Employee emp = employeeDao.fetchEmployeeById(employee.getEmployeeId()).get();
		emp.setEmployeeName(employee.getEmployeeName());
		emp.setSalary(employee.getSalary());
		emp.setDeptName(employee.getDeptName());
		return employeeDao.updateEmployee(employee);
	}
	

	
}
